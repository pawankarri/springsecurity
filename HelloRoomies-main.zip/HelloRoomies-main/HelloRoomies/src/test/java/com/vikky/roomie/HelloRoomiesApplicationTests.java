package com.vikky.roomie;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class HelloRoomiesApplicationTests {

	@Test
	void contextLoads() {
	}

}

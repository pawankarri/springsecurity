package com.vikky.roomie.dto;

public class Authority {

	private String authority;

	public Authority(String authority) {
		super();
		this.authority = authority;
	}

	public Authority() {
		super();
		
	}

	public String getAuthority() {
		return authority;
	}

	public void setAuthority(String authority) {
		this.authority = authority;
	}

}
